﻿namespace Infoss.Operation.InvoiceModel
{
    public class InvoiceExportFakturRequest : InvoiceExportFaktur
    {
        public string User { get; set; } = string.Empty;
    }
}