﻿namespace Infoss.Operation.InvoiceModel
{
    public class InvoiceExportEJKPRequest : InvoiceExportEJKP
    {
        public string User { get; set; } = string.Empty;

    }
}