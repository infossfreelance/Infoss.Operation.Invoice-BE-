﻿namespace Infoss.Operation.InvoiceModel
{
    public class InvoiceColumn
    {
        public string Column { get; set; } = string.Empty;
        public string Text { get; set; } = string.Empty;
        public string Format { get; set; } = string.Empty;
    }
}