﻿namespace Infoss.Operation.InvoiceModel
{
    public class InvoiceDetailStorageRequest : InvoiceDetailStorage
    {
        public string User { get; set; } = string.Empty;
    }
}