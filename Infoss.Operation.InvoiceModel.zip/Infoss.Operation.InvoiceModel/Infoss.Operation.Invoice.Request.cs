﻿namespace Infoss.Operation.InvoiceModel
{
    public class InvoiceRequest : Invoice
    {
        public string User { get; set; } = string.Empty;
    }
}