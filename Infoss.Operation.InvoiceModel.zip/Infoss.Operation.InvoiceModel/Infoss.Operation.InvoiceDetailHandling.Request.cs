﻿namespace Infoss.Operation.InvoiceModel
{
    public class InvoiceDetailHandlingRequest : InvoiceDetailHandling
    {
        public string User { get; set; } = string.Empty;
    }
}