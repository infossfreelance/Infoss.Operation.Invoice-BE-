﻿namespace Infoss.Operation.InvoiceModel
{
    public class InvoiceDetailDemurrageContainerDetailRequest : InvoiceDetailDemurrageContainerDetail
    {
        public string User { get; set; } = string.Empty;
    }
}