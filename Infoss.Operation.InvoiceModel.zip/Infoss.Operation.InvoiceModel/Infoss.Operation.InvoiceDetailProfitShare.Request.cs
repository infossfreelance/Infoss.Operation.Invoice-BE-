﻿namespace Infoss.Operation.InvoiceModel
{
    public class InvoiceDetailProfitShareRequest : InvoiceDetailProfitShare
    {
        public string User { get; set; } = string.Empty;
    }
}